
classes.dex permission 
invoke-static {p0}, Lcom/shawon/dts/MainActivity;->Start(Landroid/content/Context;)V



Floating permission 
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
